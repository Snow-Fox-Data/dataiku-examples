# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from datetime import datetime

import yfinance as yf

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
msft = yf.Ticker("MSFT")
data = msft.history(period="max")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
data.reset_index(inplace=True)
data['symbol'] = 'MSFT'
data['loaded'] = datetime.now()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
amzn = yf.Ticker("AMZN")
data2 = amzn.history(period="max")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
data2.reset_index(inplace=True)
data2['symbol'] = 'AMZN'
data2['loaded'] = datetime.now()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
snow = yf.Ticker("SNOW")
data3 = snow.history(period="max")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
data3.reset_index(inplace=True)
data3['symbol'] = 'SNOW'
data3['loaded'] = datetime.now()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
combined = data.append(data2, ignore_index=True)
combined = combined.append(data3, ignore_index=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
stock_data = dataiku.Dataset("stock_data")
stock_data.write_with_schema(combined)